# 프론트엔드 폴더 구조

| 버전 | 일시           | 변경 내용                                                                                                                                                                                                                                                                                                    |
| ---- | -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| v0.1 | 2026.07.16 THU | 최초 작성. 폴더 트리 · 배치 원칙 분리.                                                                                                                                                                                                                                                                        |
| v0.2 | 2026.07.17 FRI | 구조 전면 개편 — 도메인 단위(`features/`) 폐기, **화면 단위(`pages/`) + 역할 단위(`components/`, `lib/api/`)** 로 재편. 레이아웃을 `layouts/`로 분리.                                                                                                                                                        |
| v0.3 | 2026.07.17 FRI | 헤더 조립 주체를 페이지 → **레이아웃**으로 변경.                                                                                                                                                                                                                                                              |
| v0.4 | 2026.07.19 SUN | `project-form/` 내부 재편 — `ProjectFormPage`(공용) 폐기, **`ProjectCreatePage` + `ProjectSettingsPage`로 분리**(폴더는 유지). `SpecUrlField` → `SpecJsonUrlField`. **`components/PageHeading.tsx` 신설**, `EmptyState`가 이를 사용. `lib/types.ts` · `lib/constants.ts` 생성 완료. |

관련 문서

- `01-frontend-stack` — 기술 스택 · 구현 순서
- `03-frontend-layouts` — 라우트 · 레이아웃 · 반응형
- `04-design-tokens` — 색 · 폰트 · Tailwind 유틸

---

## 구조 원칙

폴더 구조의 목적은 **코드를 찾을 때 헷갈리지 않는 것** 하나다.
사람이 코드를 찾는 방식 — **"무슨 화면?"** 과 **"무슨 종류?"** — 두 축을 쓴다.

**한 화면 전용이면 `pages/`, 둘 이상 화면이 쓰면 `components/`(또는 `lib/`).**

**폴더 = 라우트 하나가 원칙이지만, 한 기능의 두 모드는 한 폴더에 묶는다.**
`project-form/`이 그 예다 — 생성과 설정은 별개 화면이지만 같은 리소스를 다루고 조각을 공유한다.
반면 `login`·`signup`은 공유 조각이 없는 별개 화면이라 각자 폴더를 유지한다.

---

## 전체 트리

```
src/
├── main.tsx                      # 엔트리. Provider 조립
│
├── app/                          # 앱 부팅 — 라우팅 · 전역 provider
│   ├── router.tsx
│   ├── ThemeContext.tsx          # light/dark, .dark 토글, localStorage
│   ├── AuthContext.tsx           # 로그인 유저·JWT (데이터 단계)
│   └── RequireAuth.tsx           # 미로그인 리다이렉트 (데이터 단계)
│
├── layouts/                      # 레이아웃 3종
│   ├── AuthLayout.tsx            # Login·Signup — 헤더X, 중앙정렬
│   ├── AppLayout.tsx             # Dashboard·ProjectCreate·ProjectSettings
│   └── SpecLayout.tsx            # SpecDetail — h-dvh flex 세로 스택
│
├── pages/                        # 화면 + 그 화면 전용 조각
│   ├── login/LoginPage.tsx
│   ├── signup/SignupPage.tsx
│   ├── dashboard/
│   │   ├── DashboardPage.tsx
│   │   ├── ProjectCard.tsx
│   │   └── NewProjectCard.tsx
│   ├── project-form/                 # 생성 · 설정 (한 기능 두 모드)
│   │   ├── ProjectCreatePage.tsx     # /projects/new — 스펙 URL 하나만
│   │   ├── ProjectSettingsPage.tsx   # /projects/:id/settings — 1컬럼
│   │   ├── SpecJsonUrlField.tsx      # 스펙 업데이트 (설정 전용)
│   │   ├── TryItBaseUrlField.tsx     # API Base URL
│   │   └── MemberList.tsx            # 멤버 초대 + 칩 목록
│   ├── spec-detail/
│   │   ├── SpecDetailPage.tsx        # 3컬럼 본문
│   │   ├── SpecColumns.tsx
│   │   ├── BearerTokenInput.tsx
│   │   ├── EndpointSidebar.tsx
│   │   ├── EndpointListItem.tsx
│   │   ├── EndpointDetail.tsx
│   │   ├── TryItPanel.tsx
│   │   ├── SpecUpdateBanner.tsx
│   │   ├── useSpecCache.ts
│   │   └── comments/
│   │       ├── CommentPanel.tsx
│   │       ├── CommentThread.tsx
│   │       ├── CommentItem.tsx
│   │       ├── CommentEditor.tsx
│   │       ├── MentionPopover.tsx
│   │       ├── CommentContent.tsx
│   │       ├── ReactionBar.tsx
│   │       ├── MoveThreadPopover.tsx
│   │       └── AiSummaryButton.tsx
│   └── NotFoundPage.tsx              # 404
│
├── components/                   # 여러 화면이 공유하는 UI
│   ├── ui/                       # shadcn 생성물
│   │   ├── button.tsx  input.tsx  label.tsx  field.tsx
│   │   ├── dropdown-menu.tsx  popover.tsx  tooltip.tsx  avatar.tsx
│   │   └── ...                   # `npx shadcn add <name>`
│   ├── Header.tsx                # 뼈대. props: left, right, wide
│   ├── Footer.tsx                # props: align = left | center | right
│   ├── BackButton.tsx
│   ├── PageHeading.tsx           # 아이콘 + 제목(h2)
│   ├── MethodBadge.tsx
│   ├── Logo.tsx
│   ├── EmptyState.tsx            # PageHeading + action
│   ├── UserMenu.tsx
│   └── NotificationDropdown.tsx  # 미구현
│
├── lib/
│   ├── api/                      # 데이터 단계에서 생성
│   │   ├── client.ts  auth.ts  projects.ts  comments.ts  notifications.ts
│   ├── queryClient.ts            # 데이터 단계
│   ├── constants.ts              # ROLE, REACTION_TYPE, NOTIFICATION_TYPE, HTTP_METHOD ✅
│   ├── types.ts                  # 백엔드 응답 타입 ✅
│   └── utils.ts                  # cn() 헬퍼
│
└── styles/index.css              # 디자인 토큰 + shadcn 매핑 + 다크
```

---

## `lib/constants.ts` — enum 표기 규칙

기준은 하나다 — **런타임에 목록을 순회하거나 값으로 참조하는가.**

| 형태                     | 쓰는 경우          | 예                               |
| ------------------------ | ------------------ | -------------------------------- |
| 배열 + `as const` + 타입 | 순회·검증이 필요함 | `REACTION_TYPES`, `HTTP_METHODS` |
| 유니온 타입만            | 비교만 함          | `ROLE`, `NOTIFICATION_TYPE`      |

```ts
export type ROLE = "OWNER" | "MEMBER";

export const REACTION_TYPES = ["DONE", "CHECKING", "BEST", "ACK"] as const;
export type REACTION_TYPE = (typeof REACTION_TYPES)[number];

export type NOTIFICATION_TYPE = "INVITED" | "MENTIONED";

export const HTTP_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"] as const;
export type HTTP_METHOD = (typeof HTTP_METHODS)[number];
```

- `as const`는 리터럴 타입으로 좁히고 읽기 전용으로 고정한다.
- `(typeof X)[number]`는 배열 요소 타입들을 유니온으로 뽑는다.
- 타입만 필요하면 이 구문을 쓰지 않는다 — 런타임에 죽은 배열만 남는다.
- **TS `enum`은 쓰지 않는다.** 런타임 객체가 번들에 남고 tree-shaking이 어렵다.

---

## `lib/types.ts` — 백엔드 응답 타입

**API 응답 body에 등장하는 타입만 옮긴다.** 서버 내부 DTO, Prisma 모델, Guard 타입은 제외.

1. **날짜는 `string`이다.** 백엔드가 `Date`로 선언했어도 JSON 직렬화되면 ISO 문자열이다.
2. **enum은 `constants.ts`에서 import한다.** 중복 정의하지 않는다.
3. `EndpointSummary.method`는 백엔드가 주는 그대로 `string`. 좁히는 책임은 렌더 시점(호출부)에 있다.

---

## 배치 판단 기준

| 이건 무엇?               | 어디?                   |
| ------------------------ | ----------------------- |
| 라우팅되는 화면          | `pages/<화면>/`         |
| 그 화면에서만 쓰는 조각  | `pages/<화면>/` 에 같이 |
| 여러 화면이 쓰는 UI      | `components/`           |
| shadcn 컴포넌트          | `components/ui/`        |
| 레이아웃 3종             | `layouts/`              |
| API 호출                 | `lib/api/<도메인>.ts`   |
| fetch 래퍼 · 유틸 · 설정 | `lib/`                  |
| 라우터 · Provider · 테마 | `app/`                  |

**애매할 때**: "이 파일을 다른 화면에서도 쓰나?"
아니오 → `pages/`, 예 → `components/`(순수 UI) 또는 `lib/`(로직·배관).

---

## 공용 조각의 책임 분리

| 조각          | 책임                        | 안 하는 것              |
| ------------- | --------------------------- | ----------------------- |
| `PageHeading` | 아이콘 + 제목(`h2`)         | 폭·여백을 정하지 않음   |
| `EmptyState`  | `PageHeading` + action 버튼 | —                       |
| `Header`      | 높이 · sticky · 좌우 배치   | 슬롯 내용을 만들지 않음 |
| `Footer`      | 하단 고정 · 정렬            | 링크를 두지 않음        |

**폭은 페이지가 정한다.** 공용 조각이 `max-w-*`를 들고 있으면 페이지 컨테이너와 이중으로 걸려
좌측 기준선이 어긋난다.

---

## 헤더는 한 덩어리가 아니다

`Header`는 **뼈대**만 갖고, 내용은 `left` · `right` · `wide` 슬롯으로 받는다.
**슬롯을 채우는 것은 레이아웃**이다. 페이지는 `Header`를 건드리지 않는다.

| 조각                    | 위치                 | 이유                        |
| ----------------------- | -------------------- | --------------------------- |
| 헤더 뼈대 (`Header`)    | `components/`        | 슬롯 받아 배치만 함         |
| 뒤로가기 (`BackButton`) | `components/`        | 여러 화면 공유, 도메인 모름 |
| 유저 메뉴 (`UserMenu`)  | `components/`        | 여러 레이아웃이 공유        |
| 알림 드롭다운           | `components/`        | UserMenu 안에서 사용        |
| Bearer 입력             | `pages/spec-detail/` | SpecDetail 전용             |
| `⚙` 설정 버튼           | `layouts/SpecLayout` | 헤더 조립 주체가 직접 렌더  |
