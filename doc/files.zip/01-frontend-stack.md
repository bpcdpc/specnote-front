# 프론트엔드 기술 스택

| 버전 | 일시           | 변경 내용                                                                                                                                                                                          |
| ---- | -------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| v0.1 | 2026.07.16 THU | 최초 작성. 스택·구현 순서·미결 항목 분리. 라틴 폰트 Inter → Geist.                                                                                                                                  |
| v0.2 | 2026.07.17 FRI | 폴더 구조 개편 반영. 구현 일정을 주 단위로 정리.                                                                                                                                                     |
| v0.3 | 2026.07.17 FRI | 상태 관리 원칙 명시 — 서버 데이터는 TanStack Query, 전역 Context는 테마·로그인 유저뿐.                                                                                                              |
| v0.4 | 2026.07.19 SUN | 구현 순서 갱신(project 화면 목 완료, `lib/types.ts`·`constants.ts` 생성). Base UI 규칙에 **`render`에 `<a>`를 넘길 때의 `nativeButton` 경고** 추가. shadcn 컴포넌트 커스텀 내역 기록. 미결 항목 정리. |

> 프로젝트 전반은 백엔드 레포 `01-overview` 참조. 이 문서는 프론트엔드 구현에 필요한 것만 다룬다.

관련 문서

- `02-frontend-directories` — 폴더 구조 · 배치 원칙
- `03-frontend-layouts` — 라우트 · 레이아웃 · 반응형
- `04-design-tokens` — 색 · 폰트 · Tailwind 유틸

---

## 기술 스택

| 항목            | 선택                                                       |
| --------------- | ---------------------------------------------------------- |
| 빌드            | Vite + React + TypeScript                                  |
| 스타일          | Tailwind CSS v4 (`@tailwindcss/vite`)                      |
| 컴포넌트        | shadcn/ui (Base UI 프리미티브, Nova 프리셋, Lucide 아이콘) |
| 라우팅          | React Router (`createBrowserRouter`)                       |
| 서버 상태       | TanStack Query                                             |
| 클라이언트 상태 | `useState` / Context                                       |
| 리사이즈        | `react-resizable-panels` (오른쪽 댓글 패널만)              |
| 마크다운 렌더   | `react-markdown` (댓글 코드블록 표시용, 저장은 평문)       |
| 폰트            | Geist(라틴) + Pretendard(한글), CDN                        |
| 다크모드        | `<html>`에 `.dark` 클래스 토글                             |

---

## 상태 관리 원칙

**서버에서 온 데이터는 Context에 담지 않는다. TanStack Query가 캐시한다.**

| 종류                 | 어디서                | 예                                               |
| -------------------- | --------------------- | ------------------------------------------------ |
| 서버 데이터          | **TanStack Query**    | 프로젝트 목록·정보, 엔드포인트, components, 알림 |
| 전역 클라이언트 상태 | **Context**           | 테마, 로그인 유저+JWT                            |
| 화면 스코프 상태     | `useState` (화면 최상단) | Bearer 토큰, 선택된 엔드포인트                   |

- **"현재 프로젝트"를 전역 상태로 들고 있지 않는다.** URL의 `:id`가 그 역할을 하고,
  여러 컴포넌트가 `useProject(id)`를 부르면 Query가 같은 캐시를 돌려준다.
- 전역 Context는 **테마 + 로그인 유저 둘뿐**이다. `ProjectContext` 같은 건 만들지 않는다.

---

## Base UI 사용 규칙 (중요)

shadcn을 **Base UI** 프리미티브로 쓴다(Radix 아님). Radix 예제를 그대로 가져오면 타입 에러가 난다.

| 하고 싶은 것                | Radix (❌)                             | Base UI (✅)                                                       |
| --------------------------- | -------------------------------------- | ------------------------------------------------------------------ |
| 컴포넌트를 다른 요소로 렌더 | `<Button asChild><Link/></Button>`     | `<Button render={<Link to="..." />}>내용</Button>`                 |
| 드롭다운 트리거             | `<Trigger asChild><button/></Trigger>` | `<DropdownMenuTrigger className="...">` (Trigger 자체가 `<button>`) |
| 메뉴 항목 클릭해도 안 닫기  | `onSelect` + `preventDefault()`        | `<DropdownMenuItem closeOnClick={false}>`                          |
| 드롭다운 라벨               | `<DropdownMenuLabel>` 단독             | `<DropdownMenuGroup>` 안에서만. 단순 표시는 `<div>`                |

- **Trigger 안에 `<button>`을 또 넣지 않는다**(중첩 button 에러).
- `DropdownMenuLabel`을 `<Group>` 밖에서 쓰면 `MenuGroupContext is missing` 에러가 난다.

### `render`에 `<a>`(Link)를 넘길 때

Base UI `Button`은 네이티브 `<button>`을 기대하므로 경고가 뜬다:

```
Base UI: A component that acts as a button expected a native <button>
because the `nativeButton` prop is true.
```

해결은 둘 중 하나. **2번을 권한다** — 링크는 의미상 `<a>`가 맞다.

1. `nativeButton={false}`를 함께 넘긴다.
2. `Button`을 쓰지 말고 `<Link>`에 버튼 스타일 클래스를 직접 입힌다. (클래스는 `04-design-tokens`)

---

## 폼 작성 규칙

**폼은 무조건 `Field` 계열로 짠다.** `<label>` + `<input>`을 수동 배치하지 않는다.

```tsx
<FieldSet>
  <FieldGroup>
    <Field>
      <FieldLabel htmlFor="email">Email</FieldLabel>
      <Input id="email" type="email" />
    </Field>
    <Field>
      <Button onClick={handleSubmit}>로그인</Button>
    </Field>
  </FieldGroup>
</FieldSet>
```

`Field`가 label↔input 간격을, `FieldGroup`이 필드 사이 간격을 잡는다. `space-y-*` 수동 조정이 불필요하다.

**입력 + 버튼을 나란히 둘 때**는 `Field` 안에서 `<div className="flex items-center gap-2">`로 감싸고
버튼에 `shrink-0`을 준다(설정 화면의 스펙 URL · Base URL · 멤버 초대가 이 패턴).

---

## 프로젝트 세팅 순서

**1. Vite 프로젝트 생성**

```bash
npm create vite@latest -- --template react-ts
```

`App.tsx` · `App.css`는 삭제한다. `main.tsx`가 `RouterProvider`를 직접 렌더한다.

**2. 라우터**

```bash
npm install react-router-dom
```

**3. Tailwind CSS v4**

```bash
npm install tailwindcss @tailwindcss/vite
```

```ts
// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({ plugins: [react(), tailwindcss()] });
```

v4에는 `tailwind.config.js`가 없다. `postcss.config.js`도, content glob 설정도 불필요하다.

**4. 경로 별칭 `@/*`**

```bash
npm install -D @types/node
```

`tsconfig.json`과 `tsconfig.app.json` 양쪽에 `"paths": { "@/*": ["./src/*"] }`를 넣고,
`vite.config.ts`에 `resolve.alias: { "@": path.resolve(__dirname, "./src") }`를 추가한다.
`baseUrl`은 넣지 않는다(최신 TS에서 deprecated).

**5. shadcn/ui**

```bash
npx shadcn@latest init
```

- Component library → **Base** (Recommended)
- Preset → **Nova** (Lucide / Geist)

경로 별칭(4)이 먼저 잡혀 있어야 한다. init이 `components.json` · `lib/utils.ts` ·
`index.css` 색 변수 블록을 생성하고, Base UI 프리미티브 등을 설치한다.

> `@fontsource-variable/geist`는 쓰지 않는다. 폰트는 CDN으로 불러온다.

**6. 디자인 토큰 — `src/styles/index.css`**

shadcn이 넣은 색 변수를 우리 토큰에 매핑하고 다크 방식·폰트를 정리한다(`04-design-tokens`).
`main.tsx`에서 `import "@/styles/index.css";`.

**7. shadcn 컴포넌트 커스텀**

`components/ui/`는 생성물이지만 **스타일 값은 고친다.** 현재 손댄 것:

- `button.tsx` — `size.default`를 `h-10 px-3`으로, 공통 radius `rounded-md`,
  `outline` variant의 기본 배경 제거(`bg-transparent`, 다크 `bg-input/30` 삭제),
  `defaultVariants.variant`를 `"outline"`으로.
- `input.tsx` — `h-10`, `rounded-md`, 전용 토큰(`border-input-border` `bg-input-bg`),
  포커스 링 제거 후 `focus-visible:border-border`.

**8. 이후 단계에서 설치**

```bash
npm install @tanstack/react-query     # 9단계  — 데이터 배관
npm install react-resizable-panels    # 11단계 — 3컬럼 리사이즈
npm install react-markdown            # 12단계 — 댓글 코드블록 렌더
```

---

## 구현 순서

**원칙**: 뼈대 → 레이아웃 → UI → 데이터. 화면은 먼저 목 데이터로 만들고 배관이 준비되면 교체한다.

| 단계 | 내용                                                                        | 상태 |
| ---- | --------------------------------------------------------------------------- | ---- |
| 0    | 디자인 토큰 · 폰트 · 다크 — `styles/index.css`                              | ✅   |
| 1    | shadcn 세팅 · 토큰 매핑 · 경로 별칭                                         | ✅   |
| 2    | 뼈대 배선 — `ThemeProvider` + `RouterProvider`                              | ✅   |
| 3    | 라우터 + stub 페이지                                                        | ✅   |
| 4    | 레이아웃 — `Header` · `Footer` · `BackButton`, 레이아웃 3종                 | ✅   |
| 5    | 공용 UI — `MethodBadge` · `Logo` · `EmptyState` · `PageHeading` · `UserMenu` | ✅   |
| 6    | auth 화면 — 로그인 · 회원가입 (Field 폼, 제출은 목)                         | ✅   |
| 7    | dashboard — 프로젝트 카드 · 빈 상태 (목)                                    | ✅   |
| 8    | header — UserMenu 완료 / **알림 드롭다운 미구현**                           | 🔶   |
| 8.5  | 타입 — `lib/constants.ts` · `lib/types.ts`                                  | ✅   |
| 9    | 데이터 배관 — `lib/api/` · QueryProvider · AuthContext → 목을 API로 교체    | ☐    |
| 10   | project — 생성 · 설정 · 멤버 (화면 목 완료, API 연결 대기)                  | 🔶   |
| 11   | spec — 사이드바 · 중앙 상세 · Try it · 갱신 배너 (3컬럼 셸만)               | 🔶   |
| 12   | comments — 2뎁스 트리 · 멘션 · 리액션 · AI 요약 · 스레드 이동               | ☐    |
| 13   | 알림 딥링크 · 댓글 하이라이트                                               | ☐    |
| 14   | 404 페이지 · 파비콘 (404 완료, 파비콘 대기)                                 | 🔶   |

**알림 드롭다운을 미룬 이유**: `UserMenu`에 자리표시만 두었다. 목록 UI만으로는 검증할 게 없고
백엔드 알림 API + 딥링크(13단계)와 함께 붙어야 의미가 있다.

---

## 미결 / 대기

### 코드 정합성 (문서와 어긋난 부분)

**Button 기본 variant가 실제로 안 먹음**
`buttonVariants.defaultVariants.variant`는 `"outline"`인데 `Button` 함수 파라미터 기본값이
`"default"`라 후자가 이긴다. `<Button>`만 쓰면 여전히 채움이다. 둘을 맞춰야 한다.

**Logo가 `h1`이라 푸터에서 계층 충돌**
`Footer`가 `Logo`를 쓰면 AppLayout 화면에 `h1`이 둘(헤더 + 푸터 로고) 생긴다.
푸터용 `<span>` 렌더로 분리 필요.

**EmptyState의 폭 중복**
`EmptyState`가 `mx-auto max-w-3xl`을 자체 보유하고 페이지도 같은 폭으로 감싼다.
"폭은 페이지가 정한다" 원칙에 따라 조각에서 빼야 한다.

**404가 Footer를 렌더함**
문서상 404는 레이아웃 밖이지만 푸터는 렌더한다. 의도면 유지, 아니면 제거.

### 기능 대기

**로그아웃 API** — 백엔드에 없다. 기능정의서 · API명세서에 추가 필요.

**파비콘** — `{S}` SVG는 폰트가 없는 환경에서 fallback 렌더된다. 정확한 자형이 필요하면
Geist 글리프를 path로 변환해야 한다(수동 작업).

**드로어 (SpecDetail 모바일)** — 후순위. 3컬럼 셸이 안정된 뒤 얹으면 가로 스크롤을 대체한다.

### 확정된 제약

**댓글은 평문 저장** (`content: string`). 리치 에디터를 쓰지 않는다.
백엔드 `Comment.content`가 평문 한 필드이고 FR-5.4가 "순수 텍스트 댓글 구조만 유지"로 못 박았다.

- `@`/`#` 멘션은 본문 인라인이 아니라 `mentionedUserIds[]` / `mentionedEndpointIds[]` 별도 배열.
- 코드블록은 렌더 시 `react-markdown`으로 표시만 한다. 저장 형식은 안 바뀐다.
- 이미지 · 동영상 첨부는 스코프 밖.

**와이어프레임 v0.1과의 차이**

- 와이어프레임은 양쪽 사이드바 리사이즈 → 실제는 **왼쪽 고정 + 오른쪽만 리사이즈**.
- 와이어프레임은 프로젝트 생성/설정이 한 화면(2컬럼) → 실제는 **두 화면, 각 1컬럼**.
